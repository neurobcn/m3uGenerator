var video;
 
window.onload = function() {
    video = document.getElementById("videoPlayer");
}
 
function play() {
    video.play();
}